// sætter datoerne for pickup og dropoff automatisk til dags dato og dagen efter
document.getElementById("pickupdate").value = new Date().toISOString().slice(0, 10);
let tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
document.getElementById("dropoffdate").value = tomorrow.toISOString().slice(0, 10);

let cars = [];

// fetch("js/cars.json")
//     .then(response => response.json())
//     .then(data => console.log(data));

/**
 * "Fetch" laver et request.
 * Henter her data omkring 3 biler i json format.
 */ 
fetch("https://api.jsonbin.io/b/6200eb564ce71361b8d18e7d")
    .then(function (response) {
        return response.json();
    })
    .then(function (post) {
        // console.log(post);
        cars = post.billiste;
        // console.log(cars);
        // return cars;
    })
    // .then(function (cars) {
    //     for(const car of cars){
    //         console.log(car);
    //     }
    // })
    // console.log(cars)

/**
 * Her hentes en række html elementer ind.
 * Disse gemmes i "const" variabler, som vi senere brugere.
 */   
const section = document.getElementById("car-type-container");
const template = document.getElementById("car-type-template-output");
const people = document.getElementById("people");
const luggage = document.getElementById("luggage");
const formular = document.getElementById("formular");
const pickupdate = document.getElementById("pickupdate");
const dropoffdate = document.getElementById("dropoffdate");

/**
 * På html elementet formular tilføjer vi en event listener.
 * Når formularen "submittes" køres den anonyme funktion.
 */ 
formular.addEventListener("submit", function (event) {
    // Ryd standard funktionaliteten for "submit" eventet
    event.preventDefault();
    // Hvis datoen er valid, så fortsæt | Ellers giv besked om, at datoerne ikke er valid.
    if (validDates(pickupdate.value, dropoffdate.value)) {
        // Reset error beskeden
        section.innerHTML = "";
        
        /**
         * "cars" er vores liste af biler fra vores request
         * For hver bil clone vores bil template og udfyld data.
         */ 
        for(const car of cars) {
            // Hvis der er matchende biler: Så hvis dem
            if (luggage.value <= car.luggage && people.value <= car.people) {
                // Udregn hvor mange dage der er mellem pickupdate og dropoffdate
                const antaldage = calculateRentalDays(pickupdate.value, dropoffdate.value);
                // Klon templaten
                const clone = template.content.cloneNode(true);
                // Gem klonens forskellige "children" html elementer i variabler
                const carbrand = clone.querySelector(".carbrand");
                const picturetag = clone.querySelector("img");
                const category = clone.querySelector(".category");
                const nopeople = clone.querySelector(".number-of-people");
                const noluggage = clone.querySelector(".number-of-luggage");
                const rentalprice = clone.querySelector(".rentalprice");
                const numberofdays = clone.querySelector(".number-of-days")
                
                // Udregn den totale pris
                let totalprice = beregnLejeudgift(antaldage, car.rentalprice);

                // Få fat i knappen, som brugere trykker på for at booke bilen
                const bookNowBtn = clone.querySelector(".booknow-btn");
                // Tilføj en event listener til hver knap, som gemmer data'en der skal bruges til næste side
                bookNowBtn.addEventListener('click', function(event){
                    // Ryd standard opførsel for linket
                    event.preventDefault();
                    // Lav JSON objekt
                    let jsonBooking = {
                        "carbrand": car.carbrand,
                        "pickupdate": pickupdate.value,
                        "dropoffdate": dropoffdate.value,
                        "numberofdays": antaldage,
                        "totalprice": totalprice,
                    };
                    /**
                     * Gem JSON objektet i den globale "sessionStorage" variabel.
                     * Da sessionStorage kun tager tekststrenge, så husk at "stringify" vores JSON objekt.
                     */ 
                    sessionStorage.setItem("jsonBooking", JSON.stringify(jsonBooking))
                    /**
                     * Naviger brugeren over til næste side i booking processen
                     * 
                     *    window.location      pathname
                     * https://skydstofte.net/udstyr.html
                     */ 
                    window.location.pathname = "udstyr.html";
                });
                
                /**
                 * Sæt værdierne i klonens html elementer (variablerne vi satte tidligere i linje 66-72)
                 * til værdierne fra bilen "car": JSON objekt fra listen "cars"
                 * og andre relevante værdier som "totalprice" udregnet tidligere.
                 */  
                picturetag.src = car.picture;
                picturetag.alt = car.picturetext;
                carbrand.textContent = car.carbrand;
                category.textContent += car.category;
                noluggage.textContent = noluggage.textContent + car.luggage;
                nopeople.textContent += car.people;
                numberofdays.textContent += antaldage;
                rentalprice.textContent = totalprice;
                // Tilføj klonen til "section" elementet
                section.appendChild(clone);
            }
        }
        // Popup besked
        alert("Du har valgt antal dage: " + calculateRentalDays(pickupdate.value, dropoffdate.value));
    } else {
        // Error message
        section.innerHTML = "Afleveringdatoen skal ligge efter afhentningsdatoen.";
    }
})

/**
 * Metoden returnere enten "false" and "true".
 * 
 * Hvis "pickupdate" er lavere end "dropoffdate" returneres "true"
 * Ellers returneres "false"
 * 
 * @param {Date} pickupdate 
 * @param {Date} dropoffdate 
 * @returns boolean
 */
function validDates(pickupdate, dropoffdate) {
    const pickup = new Date(pickupdate);
    const dropoff = new Date(dropoffdate);
    if (pickup > dropoff) {
        return false;
    } else {
        return true;
    }
};

/**
 * 
 * @param {Date} pickupdate 
 * @param {Date} dropoffdate 
 * @returns 
 */
function calculateRentalDays(pickupdate, dropoffdate) {
    const Pickup = new Date(pickupdate);
    const Dropoff = new Date(dropoffdate);
    const differenceInTime = Dropoff.getTime() - Pickup.getTime();
    const differenceInDays = differenceInTime / (1000 * 3600 * 24) + 1;
    return differenceInDays;
}

function beregnLejeudgift(antaldage, biltillaeg) {
    const MOMS = 0.25;
    const GRUNDBELOEB = 495;
    const PRISPRDAG = 100;
    const LEJEUDGIFT = (GRUNDBELOEB + (antaldage * PRISPRDAG) + (antaldage * biltillaeg)) * (1 + MOMS);
    return LEJEUDGIFT.toFixed(2);
}


