let jsonBooking = JSON.parse(sessionStorage.getItem("jsonBooking")); 
// console.log(jsonBooking.carbrand)

let yourRentalInfo = document.querySelector(".booking-page-total-booking-list");
const TOTALPRICE = sessionStorage.getItem("totalprice");

let totalprice = document.querySelector(".booking-page-total-booking-price");

totalprice.insertAdjacentHTML("afterend", `<br><p> TOTAL: ${TOTALPRICE}</p>inkl. moms`)

yourRentalInfo.insertAdjacentHTML("beforeend", "<br><p " + 
    "style='text-decoration: underline; font-size: 22px; font-style: italic; " + 
    "'>Din booking:</p><br><p>" + jsonBooking.carbrand + "</p>");
    // Jeg har inline stylet her for at prøve det af.
yourRentalInfo.insertAdjacentHTML("beforeend", `<br>Afhentningsdato: ${jsonBooking.pickupdate}`);
yourRentalInfo.insertAdjacentHTML("beforeend", `<br>Afleveringsdato: ${jsonBooking.dropoffdate}`);
yourRentalInfo.insertAdjacentHTML("beforeend", `<br>Antal dage: ${jsonBooking.numberofdays}`);
yourRentalInfo.insertAdjacentHTML("beforeend", `<br><br><p>Billeje i alt: ${jsonBooking.totalprice} kr.</p>inkl. moms`);

let gears = JSON.parse(sessionStorage.getItem("gear"));

yourRentalInfo.insertAdjacentHTML("beforeend", `<br><br>Udstyrsvalg`);

for(let gearItem of gears){
    yourRentalInfo.insertAdjacentHTML("beforeend", `<li>${gearItem}</li>`);
}

const GEARTOTALPRICE = sessionStorage.getItem("totalgearprice");
console.log(GEARTOTALPRICE)

yourRentalInfo.insertAdjacentHTML("beforeend", `<br><p>Udstyr i alt: ${GEARTOTALPRICE} </p>inkl. moms`);


// her kodes dine oplysninger/registrering
const bookNowBtn = document.getElementById("booknow-btn")
bookNowBtn.addEventListener(`click`, function(event){
    event.preventDefault();
    let inputs = document.querySelector(".booking-page-customer-info-form").elements
    let error = document.querySelector(".booking-page-customer-info-error-text")
    let success = document.querySelector(".booking-page-customer-info--success")

    // Simpel form validering af input felterne
    for(let i = 0; i < inputs.length - 1; i++){
        error.textContent = "";
        // Vi tjekker om input feltets værdi er 0
        if(inputs[i].value.length == 0){
            error.textContent = "Er det svært at udfylde et tekstfelt?";
            return;
        // Ellers tjek om input feltet er en checkbox og hvis den er det, så kontroller, at den er krydset af.
        } else if(inputs[i].type == "checkbox" && !inputs[i].checked){
            error.textContent = "Hov, du er jo ikke myndig.";
            return;
        }
    }

    // Gennemløb alle input felterne bortset fra de to sidste, som er Checkbox og Button
    for(let i = 0; i < inputs.length - 2; i++){
        // Udskriv beskrivelser + input-værdier i <p> tags
        success.insertAdjacentHTML("beforeend", "<p>" + inputs[i].dataset.description + " " + inputs[i].value + "</p>");
    }
    // Tilføj "Udskriv" knappen
    success.insertAdjacentHTML("beforeend", "<button type='submit' class='print-button'>Udskriv</button>");

    // Fjern "hidden" attributten fra success <div>, som holder på den indtastede data
    success.removeAttribute('hidden');
    
    // Tilføj class variation til den gamle form, og gem med css
    let oldForm = document.querySelector(".booking-page-customer-info")
    oldForm.className += "--hide";
});
