// Step 2
// Hent json object fra sessionStorage
// Generer "LEJEASIDE"

let jsonBooking = JSON.parse(sessionStorage.getItem("jsonBooking")); 
// console.log(jsonBooking.carbrand)

let yourCarInfo = document.querySelector(".your-car-info");

yourCarInfo.insertAdjacentHTML("beforeend", "<p>" + jsonBooking.carbrand + "</p>");
yourCarInfo.insertAdjacentHTML("beforeend", `<br>Afhentningsdato: ${jsonBooking.pickupdate}`);
yourCarInfo.insertAdjacentHTML("beforeend", `<br>Afleveringsdato: ${jsonBooking.dropoffdate}`);
yourCarInfo.insertAdjacentHTML("beforeend", `<br>Antal dage: ${jsonBooking.numberofdays}`);
yourCarInfo.insertAdjacentHTML("beforeend", `<br><br><p>Billeje i alt: ${jsonBooking.totalprice.
toLocaleString('da-DK', {style: 'currency', currency: 'DKK'})}</p>inkl. moms`);

const totalValue = document.getElementById("total-value");
totalValue.textContent = jsonBooking.totalprice;
let totalprice = parseFloat(jsonBooking.totalprice);

let extraGear = document.getElementById("checkboxes").children;
for (let gear of extraGear ){
    // gear = <li> | firstChild = checkbox
    let checkbox = gear.firstChild;
    checkbox.addEventListener('click', function() {
        // Find ud af om checkboxen er checked eller ej
        // console.log(checkbox.checked)
        // console.log(checkbox.value)

        if (checkbox.checked) {
            // Hvis den er checked, så tilføj checkboxens value til totalprice
            totalprice += parseFloat(checkbox.value);
        } else {
            // Hvis ikke den er checked, så træk checkboxens value fra totalprice
            totalprice -= parseFloat(checkbox.value);
        }

        // opdater "alt inklusiv" med totalprice
        totalValue.textContent = totalprice
    });
}
// Når der trykkes på kappen bliver man sendt tilbage til index.html siden (Forsiden)
document.getElementById("back").addEventListener("click", function (event) {
    event.preventDefault()
    window.location.href="index.html"
});

const formular = document.getElementById("gear-checkboxes");
formular.addEventListener("submit", function saveGear(event) {
    event.preventDefault()
    let gearList = [];
    let totalGearPrice = 0;
    for (const gear of extraGear){
        let checkbox = gear.firstChild;
        if (checkbox.checked === true) {
            totalGearPrice += parseFloat(checkbox.value);
            gearList.push(checkbox.dataset.gear)
        }
    }

    sessionStorage.setItem("gear", JSON.stringify(gearList));
    sessionStorage.setItem("totalprice", totalprice.toLocaleString('da-DK', {style: 'currency', currency: 'DKK'}));
    sessionStorage.setItem("totalgearprice", totalGearPrice.toLocaleString('da-DK', {style: 'currency', currency: 'DKK'}));
    window.location.href="kunde.html";
});

