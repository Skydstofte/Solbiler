// Der skulle have været en slider med anmeldelser og en "kontakt os" formular
// Men jeg har haft for travlt med at være syg og har derfor været
// et par selvstudie-dage bagud hele tiden.. 
// Og så har jeg prioriteret at forstå JS koden til alle de andre ting udover "om os".